package com.wencheng.util.google.earth.kml;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

/**
 * Created by wencheng on 2020/6/19.
 */
@NoArgsConstructor
@AllArgsConstructor
public class Trace {
    // 一行数据,每个实时位置点信息
    public Map<String, Object> data;

    public Date timestamp;
    public BigDecimal lng;
    public BigDecimal lat;

    public Trace(Map<String, Object> result) {
        this.data = result;
        this.timestamp = (Date) this.data.get("时间戳");
        this.lng = (BigDecimal) this.data.get("经度_wgs84");
        this.lat = (BigDecimal) this.data.get("纬度_wgs84");
    }

}
