package com.wencheng.util.google.earth.enums;

import com.wencheng.util.google.earth.util.DateUtils;

import java.util.Map;
import java.util.Objects;

/**
 * Created by wencheng on 2020/6/19.
 */
public enum DataType {

    Date("string"),
    BigDecimal("double"),
    String("string"),
    ;

    DataType(java.lang.String kmlType) {
        this.kmlType = kmlType;
    }

    private String kmlType;

    public java.lang.String getKmlType() {
        return kmlType;
    }

    public static DataType getType(Object value) {
        if (value instanceof java.util.Date) {
            return Date;
        } else if (value instanceof java.math.BigDecimal) {
            return BigDecimal;
        } else {
            return String;
        }
    }

    public static DataType getType(Map<String, Object> map, String key) {
        Object o = map.get(key);
        return getType(o);
    }

    public static String convert2String(Map<String, Object> map, String key) {
        Object o = map.get(key);
        if (Objects.isNull(o)) {
            return "null";
        }
        DataType type = getType(o);
        if (Date == type) {
            return DateUtils.format((java.util.Date) o, DateUtils.DATE_FORMAT_STANDARD_YYYYMMDDHHMMSS);
        } else {
            try {
                return o.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "null";
        }
    }

}