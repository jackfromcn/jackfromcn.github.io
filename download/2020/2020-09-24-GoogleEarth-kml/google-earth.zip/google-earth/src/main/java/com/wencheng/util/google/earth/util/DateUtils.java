package com.wencheng.util.google.earth.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

/**
 * @author wy_sure on 2019/3/6.
 */
@Slf4j
public class DateUtils {
    public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";
    public static final String DATE_FORMAT_YYMMDD = "yyMMdd";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    public static final String DATE_FORMAT_STANDARD_YYYYMMDDHHMMSS = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT_STANDARD_YYYYMMDD = "yyyy-MM-dd";
    public static final String DATE_FORMAT_HHMMSS = "HHmmss";
    public static final String DATE_FORMAT_YYYYMM = "yyyyMM";
    public static final String DATE_FORMAT_YYYYMMDDHHMMSSS = "yyyyMMddHHmmssSSS";
    public static final String DATE_FORMAT_HHMM = "HH:mm";
    public static final String DATE_FORMAT_HH_MM_ss = "HH:mm:ss";
    public static final String DATE_FORMAT_YYYYMMDDHHMM_SSS = "yyyy-MM-dd HH:mm:ss.SSS";
    public static final String DATE_FORMAT_YYYYMMDD_HHMMSS = "yyyyMMdd HHmmss";


    public static int getDiffDays(Date start, Date end) {
        Calendar startCalendar = Calendar.getInstance();
        startCalendar.setTime(start);
        accurateToDay(startCalendar);

        Calendar endCalendar = Calendar.getInstance();
        endCalendar.setTime(end);
        accurateToDay(endCalendar);

        int days = (int) ((endCalendar.getTime().getTime() / 1000) - (startCalendar.getTime().getTime() / 1000)) / 3600 / 24;

        return days;
    }

    public static Date getDayStart(Date date) {
        return parse(format(date, DATE_FORMAT_STANDARD_YYYYMMDD), DATE_FORMAT_STANDARD_YYYYMMDD);
    }

    public static Date getDayEnd(Date date) {
        Date dayStart = getDayStart(date);
        return new Date(dayStart.getTime() + 86399_000);
    }

    /**
     * 加天数
     *
     * @param date
     * @param days
     * @return
     */
    public static Calendar addDays(Date date, int days) {
        Calendar dateCalendar = Calendar.getInstance();
        dateCalendar.setTime(date);

        dateCalendar.add(Calendar.DAY_OF_YEAR, days);

        return dateCalendar;
    }

    /**
     * 加小时
     *
     * @param date
     * @param hour
     * @return
     */
    public static Calendar addHours(Date date, int hour) {
        Calendar dateCalendar = Calendar.getInstance();
        dateCalendar.setTime(date);
        dateCalendar.add(Calendar.HOUR_OF_DAY, hour);
        return dateCalendar;
    }

    /**
     * 加
     *
     * @param date
     * @param second
     * @return
     */
    public static Calendar addSeconds(Date date, int second) {
        Calendar dateCalendar = Calendar.getInstance();
        dateCalendar.setTime(date);
        dateCalendar.add(Calendar.SECOND, second);
        return dateCalendar;
    }

    /**
     * 加天数
     *
     * @param calendar
     * @param days
     * @return
     */
    public static Calendar addDays(Calendar calendar, int days) {
        calendar.add(Calendar.DAY_OF_YEAR, days);
        return calendar;
    }

    /**
     * @param date
     * @param field
     * @param step
     * @return
     */
    public static Calendar addFieldStep(Date date, int field, int step) {
        Calendar dateCalendar = Calendar.getInstance();
        dateCalendar.setTime(date);

        dateCalendar.add(field, step);

        return dateCalendar;
    }

    /**
     * 精确到天，忽略时分秒、毫秒
     *
     * @param endCalendar
     */
    public static void accurateToDay(Calendar endCalendar) {
        endCalendar.set(Calendar.HOUR_OF_DAY, 0);
        endCalendar.set(Calendar.MINUTE, 0);
        endCalendar.set(Calendar.SECOND, 0);
        endCalendar.set(Calendar.MILLISECOND, 0);
    }

    public static Date parse(String date, String pattern) {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        try {
            return sdf.parse(date);
        } catch (ParseException e) {
            log.error("字符串转日期异常", e);
        }
        return null;
    }

    public static String format(Calendar calendar, String pattern) {
        return format(calendar.getTime(), pattern);
    }

    public static String format(Date date, String pattern) {
        try {
            if (StringUtils.isBlank(pattern)) {
                pattern = DATE_FORMAT_STANDARD_YYYYMMDDHHMMSS;
            }
            return DateFormatUtils.format(date, pattern);
        } catch (Exception e) {
            log.error("日期转字符串异常", e);
        }
        return null;
    }

    /**
     * 获取某个距离当前月的某个月的第一天的起始时间
     * eg:2018-09-08 00:00:00
     *
     * @param month 距离当前月的某个月
     * @return
     */
    public static String getBeginDate(Integer month) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.MONTH, month);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.DATE, 1);
            return DateFormatUtils.format(calendar.getTime(), DateUtils.DATE_FORMAT_STANDARD_YYYYMMDDHHMMSS);
        } catch (Exception e) {
            log.error("获取起始日期失败 getBeginDate e:{}", e);
        }
        return null;
    }

    public static String getDateYYYYMM(Integer month) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.MONTH, month);
            calendar.set(Calendar.HOUR_OF_DAY, 0);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.DATE, 1);
            return DateFormatUtils.format(calendar.getTime(), DateUtils.DATE_FORMAT_YYYYMM);
        } catch (Exception e) {
            log.error("获取起始日期失败 getBeginDate e:{}", e);
        }
        return null;
    }

    /**
     * 获取某个距离当前月的某个月的最后一天的结束时间
     * eg:2018-09-08 00:00:00
     *
     * @param month 距离当前月的某个月
     * @return
     */
    public static String getEndDate(Integer month) {
        try {
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.MONTH, month);
            calendar.set(Calendar.HOUR_OF_DAY, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 59);
            calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
            return DateFormatUtils.format(calendar.getTime(), DateUtils.DATE_FORMAT_STANDARD_YYYYMMDDHHMMSS);
        } catch (Exception e) {
            log.error("获取结束日期失败 getEndDate e:{}", e);
        }
        return null;
    }

    /**
     * 获取此刻与今天起始时间相隔的秒数
     *
     * @return
     */
    public static int getDaySecondsTtl() {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime time = LocalDate.now().atStartOfDay();
        return (int) Duration.between(time, now).toMillis() / 1000;
    }

    /**
     * 根据相对今天起始的ttl获取Date对象
     *
     * @param ttl
     * @return
     */
    public static Date getDateByTtl(int ttl) {
        return Date.from(LocalDate.now().atStartOfDay().plusSeconds(ttl).atZone(ZoneId.systemDefault()).toInstant());
    }

    /**
     * timestamp时间转换
     * @param timestamp
     * @param format
     * @return
     */
    public static String getTimeFromTimeStamp (Timestamp timestamp, String format) {
        String tsStr = "";
        try {
            if (timestamp == null) {
                return tsStr;
            }

            DateFormat sdf = new SimpleDateFormat(format);
            //方法一
            tsStr = sdf.format(timestamp);
        } catch (Exception e) {
            log.error("TimeStamp转换时间异常");
        }

        return tsStr;
    }

    // 转为 UTC时间
    public static String formate2UTC(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int zoneOffset = calendar.get(Calendar.ZONE_OFFSET);
        int dstOffset = calendar.get(Calendar.DST_OFFSET);
        calendar.add(Calendar.MILLISECOND, -(zoneOffset + dstOffset));
//        long timeInMillis = calendar.getTimeInMillis();
        return DateUtils.format(calendar, "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
//        System.out.println(df.format(timeInMillis));
    }

}
