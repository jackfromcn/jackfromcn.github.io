package com.wencheng.util.google.earth.kml;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.wencheng.util.google.earth.enums.DataType;
import com.wencheng.util.google.earth.util.DateUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import java.io.*;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Created by wencheng on 2020/6/19.
 */
public class KmlHelpler {

    public static void main(String[] args) {

    }

    /**
     *
     * @param addData  所有的数据
     * @param rootFolder googleEarth 中根目录展示
     * @param filePath 存储文件目录
     * @param fileName 文件名
     * @return
     * @throws IOException
     */
    //travelRecords代表一个地理信息的对象集合（自定义）  生成kml的名称
    public static boolean setAllTravelsKml(List<Trace> addData, String rootFolder, String filePath, String fileName, Function<Trace, String> subFolderFunc) throws IOException {
        Multimap<String, Trace> busGroup = ArrayListMultimap.create();
        for (Trace map: addData) {
            // 子文件夹名
            String subFolderName = subFolderFunc.apply(map);
            busGroup.put(subFolderName, map);
        }

        // 每行数据,后面放在每个实时点中的备注信息展示
        Trace trace = addData.get(0);
        List<String> titles = trace.data.entrySet().stream().map(Map.Entry::getKey).collect(Collectors.toList());

        Element root = DocumentHelper.createElement("kml");
        Document document = DocumentHelper.createDocument(root);
        //根节点添加属性
        root.addAttribute("xmlns", "http://www.opengis.net/kml/2.2")
                .addAttribute("xmlns:gx", "http://www.google.com/kml/ext/2.2")
                .addAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
                .addAttribute("xsi:schemaLocation",
                        "http://www.opengis.net/kml/2.2 http://schemas.opengis.net/kml/2.2.0/ogckml22.xsd http://www.google.com/kml/ext/2.2 http://code.google.com/apis/kml/schema/kml22gx.xsd");
        Element documentElement = root.addElement("Document");
        documentElement.addElement("name").addText(fileName);
        documentElement.addElement("Snippet").addText("");

        // 定义每个点的样式
        addSchema(documentElement,rootFolder, titles, trace);

        // 填充每组的数据
        for (String group: busGroup.keySet()) {
            List<Trace> travelRecords = busGroup.get(group).stream()
                    .sorted((i1, i2) -> i1.timestamp.compareTo(i2.timestamp))
                    .collect(Collectors.toList());
            Element folderElement = documentElement.addElement("Folder");//添加一个目录
            folderElement.addAttribute("id", "FeatureLayer0_line");
            folderElement.addElement("name").addText(group); //名称
            folderElement.addElement("Snippet").addText(""); //显示在Google Earth之中的对description的简短概要.

            //生成点位图标数据
            setCoord(travelRecords, folderElement, rootFolder, titles);

            //生成轨迹线路径数据
            setLine(travelRecords, folderElement);
        }

        //创建kml到本地
        OutputFormat format = OutputFormat.createPrettyPrint();
        format.setEncoding("utf-8");
        filePath = filePath.endsWith("/") ? filePath : filePath + "/";
        XMLWriter xmlWriter = new XMLWriter(new FileOutputStream(filePath + fileName + "_1.kml"),format);

        xmlWriter.write(document);

        xmlWriter.close();
        return true;
    }

    private static void setCoord(List<Trace> travelRecords, Element parentElement, String rootFolder, List<String> titles) {
        Element folderElement = parentElement.addElement("Folder");//添加一个目录
        folderElement.addAttribute("id", "FeatureLayer0");
        folderElement.addElement("name").addText("轨迹点位"); //名称
        folderElement.addElement("Snippet").addText(""); //显示在Google Earth之中的对description的简短概要.
        //生成点位图标数据
        int i = 0;
        for (Trace travelRecord:travelRecords) {
            i++;
            Element placeMarkElement = folderElement.addElement("Placemark");//在文件夹中添加一个地标
            placeMarkElement.addAttribute("id", String.valueOf(i));
            placeMarkElement.addElement("name").addText("点位"+String.valueOf(i));
            placeMarkElement.addElement("Snippet").addText("");
            placeMarkElement.addElement("description").addText("");//简介
            placeMarkElement.addElement("styleUrl").addText("#pointStyleMap");//风格
            // 根据整个时间轴顺序进行动画轨迹展示
            placeMarkElement.addElement("TimeStamp").addText(DateUtils.formate2UTC(travelRecord.timestamp));//时间

            // 展示样式
            Element style = placeMarkElement.addElement("Style");
            style.addAttribute("id", "inline");
            Element iconStyle = style.addElement("IconStyle");
            iconStyle.addElement("color").addText("ffededed");
            iconStyle.addElement("colorMode").addText("normal");

            Element lineStyle = style.addElement("LineStyle");
            lineStyle.addElement("color").addText("ffededed");
            lineStyle.addElement("colorMode").addText("normal");

            Element polyStyle = style.addElement("PolyStyle");
            polyStyle.addElement("color").addText("ffededed");
            polyStyle.addElement("colorMode").addText("normal");

            // 展示数据
            setExtendedData(placeMarkElement, rootFolder, titles, travelRecord);
            Element pointElement = placeMarkElement.addElement("Point");
            pointElement.addElement("altitudeMode").addText("clampToGround");
            //添加点位的经纬度坐标以及高度(显示时绘制高度m)
            pointElement.addElement("coordinates").addText(travelRecord.lng+","+travelRecord.lat+",0");//可以是是任何几何形状的子元素，定义每一个点的经度、纬度和高度(按照严格的顺序). 多个点使用空格隔开，经纬度按照WGS84标准.
        }
    }

    private static void setLine(List<Trace> travelRecords, Element parentElement) {
        //生成轨迹线路径数据
        Element lineElement = parentElement.addElement("Placemark");//在文件夹外添加一个地标
        lineElement.addElement("name").addText("轨迹线");
        lineElement.addElement("description").addText("");
        // 设置风格
        setStyle(parentElement);
        lineElement.addElement("styleUrl").addText("#MyStyle");
        Element pointElement = lineElement.addElement("LineString");
        pointElement.addElement("altitudeMode").addText("absolute");
        pointElement.addElement("extrude").addText("1");
        pointElement.addElement("tessellate").addText("1");
        String linedata="";
        //每个坐标以及高度用换行符或空格分开
        for (Trace travelRecord:travelRecords) {
            linedata =linedata+"\n"+ travelRecord.lng+","+travelRecord.lat+",30";
        }
        pointElement.addElement("coordinates").addText(linedata);
    }

    private static void setStyle(Element parentElement) {
        //生成显示风格
        Element styleElement = parentElement.addElement("Style");//Style节点
        styleElement.addAttribute("id", "MyStyle");
        // IconStyle 图标风格
        Element iconStyleElement = styleElement.addElement("IconStyle");
        Element iconElement = iconStyleElement.addElement("Icon");
	        iconElement.addElement("href").addText("https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=595011200,2872441748&fm=15&gp=0.jpg");//在线图标
        iconStyleElement.addElement("scale").addText("0.500000");
        // LabelStyle  标签风格
        Element labelStyleElement = styleElement.addElement("LabelStyle");
        labelStyleElement.addElement("color").addText("00000000");
        labelStyleElement.addElement("scale").addText("0.000000");
        // PolyStyle 图形风格
        Element polyStyleElement = styleElement.addElement("PolyStyle");
        polyStyleElement.addElement("color").addText("5f00ff00");
        polyStyleElement.addElement("outline").addText("0");

        // LineStyle  路径线风格
        Element lineStyleElement = styleElement.addElement("LineStyle");
        lineStyleElement.addElement("color").addText("7f00ffff");
        lineStyleElement.addElement("width").addText("4");
    }

    /**
     * 定义实时轨迹点的样式
     * 1. 备注信息
     * 2. 每个点展示样式
     * 3. 鼠标靠近时,点的样式
     * @param parentElement
     * @param rootFolder
     * @param titles
     * @param trace
     */
    private static void addSchema(Element parentElement, String rootFolder, List<String> titles, Trace trace) {
        Element schema = parentElement.addElement("Schema");
        schema.addAttribute("id", "S_" + rootFolder + "_SDD");
        schema.addAttribute("name", rootFolder);

        for (String title: titles) {
            Element simpleField = schema.addElement("SimpleField");

            DataType type = DataType.getType(trace.data, title);

            simpleField.addAttribute("type", type.getKmlType())
                    .addAttribute("name", title);

            Element displayName = simpleField.addElement("displayName");
//            displayName.addText("&lt;b&gt;" + title + "&lt;/b&gt;");
            displayName.addText("<b>" + title + "</b>");
        }

        // CDATA
        String CDATA = getCDATA(rootFolder, titles);

        // 鼠标靠近是样式
        Element style1 = parentElement.addElement("Style");
        style1.addAttribute("id", "hlightPointStyle");
        Element iconStyle1 = style1.addElement("IconStyle");
        Element icon1 = iconStyle1.addElement("Icon");
        icon1.addElement("href").addText("http://maps.google.com/mapfiles/kml/paddle/red-stars.png");
        iconStyle1.addElement("scale").addText("0.700000");
        Element balloonStyle1 = style1.addElement("BalloonStyle");
        Element text1 = balloonStyle1.addElement("text");
        text1.addCDATA(CDATA);

        Element style = parentElement.addElement("Style");
        style.addAttribute("id", "normPointStyle");
        Element iconStyle = style.addElement("IconStyle");
        Element icon = iconStyle.addElement("Icon");
        icon.addElement("href").addText("http://maps.google.com/mapfiles/kml/shapes/bus.png");
        iconStyle.addElement("scale").addText("0.700000");
        Element balloonStyle = style.addElement("BalloonStyle");
        Element text = balloonStyle.addElement("text");
        text.addCDATA(CDATA);

        Element styleMap = parentElement.addElement("StyleMap");
        styleMap.addAttribute("id", "pointStyleMap");

        Element pair = styleMap.addElement("Pair");
        pair.addElement("key").addText("normal");
        pair.addElement("styleUrl").addText("#normPointStyle");

        Element pair1 = styleMap.addElement("Pair");
        pair1.addElement("key").addText("highlight");
        pair1.addElement("styleUrl").addText("#hlightPointStyle");

    }

    /**
     * 生成 每个点备注信息展示的样式,展示表格样式
     * @param rootFolder
     * @param titles
     * @return
     */
    private static String getCDATA(String rootFolder, List<String> titles) {
        Document balloonStyleText = DocumentHelper.createDocument();
        Element table = balloonStyleText.addElement("table");
        table.addAttribute("border", "0");
        for (String title: titles) {
            Element tr = table.addElement("tr");
            tr.addElement("td").addElement("b").addText(title);
            tr.addElement("td").addText("$[" + rootFolder + "/" + title + "]");
        }

        String CDATA = "";
        try {
            StringWriter out = new StringWriter();
            XMLWriter xw = new XMLWriter (out, new OutputFormat (" ", true, "utf-8"));
            xw.write(table);
            CDATA = out.toString();
        } catch (Exception e) {
            throw new RuntimeException("CDATA 异常");
        }

        return CDATA;
    }

    /**
     * 鼠标点击时,展示扩展的备注信息
     * @param parentElement
     * @param rootFolder
     * @param titles
     * @param trace
     */
    private static void setExtendedData(Element parentElement, String rootFolder, List<String> titles, Trace trace) {
        Element extendedData = parentElement.addElement("ExtendedData");
        Element schemaData = extendedData.addElement("SchemaData");
        schemaData.addAttribute("schemaUrl", "#S_" + rootFolder + "_SDD");

        for (String title: titles) {
            Element simpleData = schemaData.addElement("SimpleData");
            Element name = simpleData.addAttribute("name", title);
            String value = DataType.convert2String(trace.data, title);
            name.addText(value);
        }
    }

    private static void setHideStyle(Element parentElement) {
        //生成显示风格
        Element styleElement = parentElement.addElement("Style");//Style节点
        styleElement.addAttribute("id", "check-hide-children");
        Element listStyle = styleElement.addElement("ListStyle");
        listStyle.addElement("listItemType").addText("checkHideChildren");
        parentElement.addElement("styleUrl").addText("#check-hide-children");
    }

    public static void writeKml(String[] strs, String kmlName) throws IOException
    {
        String[] files = strs;
        OutputStream os = new BufferedOutputStream( new FileOutputStream(kmlName + ".kml"));
        ZipOutputStream zos = new ZipOutputStream(os);
        byte[] buf = new byte[8192];
        int len;
        for (int i=0;i < files.length;i++) {
            File file = new File(files[i]);
            if ( !file.isFile() )
                continue;
            ZipEntry ze = new ZipEntry( file.getName() );
            zos.putNextEntry( ze );
            BufferedInputStream bis = new BufferedInputStream( new FileInputStream( file ) );
            while ( ( len = bis.read( buf ) ) > 0 ) {
                zos.write( buf, 0, len );
            }
            zos.closeEntry();
            bis.close();
        }

        zos.closeEntry();
        zos.close();
        os.close();

    }

}
